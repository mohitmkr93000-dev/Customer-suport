package com.example.customersupport;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    final int navy = Color.rgb(5, 20, 53), blue = Color.rgb(0, 160, 245);
    LinearLayout root;
    SharedPreferences prefs;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        prefs = getSharedPreferences("admin", MODE_PRIVATE);
        if (prefs.getString("hash", null) == null) showSetup(); else showLogin();
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER); return t;
    }
    EditText field(String hint, boolean pass) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xffb6c5dc); e.setHint(hint); e.setPadding(28, 18, 28, 18);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        if(pass) e.setInputType(129); return e;
    }
    Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        b.setOnClickListener(v -> action.run()); return b;
    }
    void begin(String title) {
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(26, 28, 26, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(navy);
        ScrollView sc = new ScrollView(this); sc.addView(root); setContentView(sc);
        TextView brand = text("🎧  CUSTOMER SUPPORT", 24, Color.WHITE, true);
        brand.setPadding(0, 22, 0, 10); root.addView(brand);
        root.addView(text(title, 17, 0xff42c8ff, true));
    }
    void showSetup() {
        begin("Create your admin password");
        root.addView(text("Admin ID: admin123", 16, Color.WHITE, true));
        root.addView(text("First-time setup: choose a password and keep it safe.", 14, 0xffc6d4e8, false));
        EditText p = field("Create password (minimum 8 characters)", true); root.addView(p);
        EditText c = field("Confirm password", true); root.addView(c);
        root.addView(button("Save password", () -> {
            String a=p.getText().toString(), d=c.getText().toString();
            if(a.length()<8) { msg("Password must be at least 8 characters"); return; }
            if(!a.equals(d)) { msg("Passwords do not match"); return; }
            try { prefs.edit().putString("hash", hash(a)).apply(); showLogin(); }
            catch(Exception ex) { msg("Could not save password"); }
        }));
    }
    void showLogin() {
        begin("Admin Login");
        root.addView(text("Sign in to manage customer support", 14, 0xffc6d4e8, false));
        EditText id=field("Admin ID", false); id.setText("admin123"); root.addView(id);
        EditText p=field("Password", true); root.addView(p);
        root.addView(button("Login", () -> {
            try {
                if(!"admin123".equals(id.getText().toString().trim())) { msg("Invalid Admin ID"); return; }
                if(!hash(p.getText().toString()).equals(prefs.getString("hash",""))) { msg("Incorrect password"); return; }
                showDashboard();
            } catch(Exception ex) { msg("Login failed"); }
        }));
        root.addView(text("Forgot password? For this offline starter, reinstalling app resets setup.", 12, 0xffaebbd0, false));
    }
    void showDashboard() {
        begin("Admin Dashboard");
        root.addView(text("Welcome, admin123", 18, Color.WHITE, true));
        String[] items={"1. User Management","2. Customer Messages","3. Support Tickets","4. All Users Details","5. Admin Settings"};
        String[] desc={"Manage user accounts","View and reply to customer messages","Track complaints and requests","View registered user information","Manage local app settings"};
        for(int i=0;i<items.length;i++){
            final int n=i;
            TextView card=text(items[i]+"\n"+desc[i],17,Color.WHITE,true);
            card.setBackgroundTintList(null); card.setBackgroundColor(0xff102d5c);
            card.setPadding(12,22,12,22); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
            lp.setMargins(0,12,0,4); root.addView(card,lp);
            card.setOnClickListener(v -> showSection(items[n],desc[n]));
        }
        root.addView(button("Logout", this::showLogin));
    }
    void showSection(String title,String desc) {
        begin(title); root.addView(text(desc,16,Color.WHITE,false));
        root.addView(text("This starter screen is ready for feature integration.",14,0xffc6d4e8,false));
        root.addView(button("Back to Dashboard",this::showDashboard));
    }
    String hash(String s) throws Exception {
        byte[] b=MessageDigest.getInstance("SHA-256").digest(("CustomerSupport:"+s).getBytes("UTF-8"));
        StringBuilder out=new StringBuilder(); for(byte x:b) out.append(String.format("%02x",x)); return out.toString();
    }
    void msg(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
